#!/bin/bash
# Ayyıldız Haber Ajansı - VPS Kurulum Scripti

set -e

echo "=== Ayyıldız Haber Ajansı Kurulumu ==="

# Sistem güncelleme
apt update && apt upgrade -y

# Gerekli paketler
apt install -y python3 python3-pip python3-venv nginx postgresql postgresql-contrib git curl

# PostgreSQL yapılandırma
systemctl start postgresql
systemctl enable postgresql

# Veritabanı kullanıcısı
sudo -u postgres createuser --createdb ayyildizhaber 2>/dev/null || true
sudo -u postgres createdb ayyildizhaber_db -O ayyildizhaber 2>/dev/null || true
sudo -u postgres psql -c "ALTER USER ayyildizhaber PASSWORD 'ayyildiz123';"

# Uygulama dizini
mkdir -p /opt/ayyildizhaber
cp -r * /opt/ayyildizhaber/
cd /opt/ayyildizhaber

# Python ortamı
python3 -m venv venv
source venv/bin/activate

# Paket kurulumu
pip install --upgrade pip
pip install Flask Flask-SQLAlchemy Flask-Login psycopg2-binary
pip install gunicorn requests beautifulsoup4 lxml trafilatura
pip install APScheduler python-dateutil email-validator feedparser

# Çevre değişkenleri
export DATABASE_URL="postgresql://ayyildizhaber:ayyildiz123@localhost/ayyildizhaber_db"
export SESSION_SECRET=$(openssl rand -base64 32)

# Veritabanı oluşturma
python3 -c "
import os
os.environ['DATABASE_URL'] = 'postgresql://ayyildizhaber:ayyildiz123@localhost/ayyildizhaber_db'
os.environ['SESSION_SECRET'] = '$(openssl rand -base64 32)'
from app import app, db
with app.app_context():
    db.create_all()
    print('Veritabanı hazır!')
"

# Nginx yapılandırması
cat > /etc/nginx/sites-available/ayyildizhaber << 'EOF'
server {
    listen 80;
    server_name _;
    
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    location /static/ {
        alias /opt/ayyildizhaber/static/;
        expires 30d;
    }
}
EOF

ln -sf /etc/nginx/sites-available/ayyildizhaber /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

# Systemd servisi
cat > /etc/systemd/system/ayyildizhaber.service << 'EOF'
[Unit]
Description=Ayyıldız Haber Ajansı
After=network.target postgresql.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/ayyildizhaber
Environment=DATABASE_URL=postgresql://ayyildizhaber:ayyildiz123@localhost/ayyildizhaber_db
Environment=SESSION_SECRET=your-secret-key-here
ExecStart=/opt/ayyildizhaber/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 3 main:app
Restart=always

[Install]
WantedBy=multi-user.target
EOF

# Servisi başlat
systemctl daemon-reload
systemctl enable ayyildizhaber
systemctl start ayyildizhaber

echo "=== Kurulum Tamamlandı ==="
echo "Web sitesi: http://$(hostname -I | awk '{print $1}')"
echo "Admin paneli: http://$(hostname -I | awk '{print $1}')/admin"
echo "Varsayılan admin: admin@gmail.com / admin123"
