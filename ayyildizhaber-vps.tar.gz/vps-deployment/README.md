# Ayyıldız Haber Ajansı - VPS Kurulumu

## Ubuntu 24.04 VPS Kurulum Paketi

### Domain ve IP Bilgileri
- **Domain**: www.ayyildizajans.com
- **IP**: 69.62.110.158
- **SSL**: Let's Encrypt otomatik sertifika

### Kurulum Adımları

1. **Paketi VPS'e yükleyin:**
```bash
scp -r vps-deployment/ root@69.62.110.158:/tmp/
```

2. **VPS'e bağlanın:**
```bash
ssh root@69.62.110.158
```

3. **Hızlı kurulum:**
```bash
cd /tmp/vps-deployment
chmod +x quick-deploy.sh
./quick-deploy.sh
```

### Kurulum Sonrası

- **Web sitesi**: https://www.ayyildizajans.com
- **IP erişimi**: https://69.62.110.158
- **Admin paneli**: https://www.ayyildizajans.com/admin
- **Varsayılan admin**: admin@gmail.com / admin123

### DNS Ayarları

Domain sağlayıcınızda aşağıdaki kayıtları ekleyin:

```
A    @                69.62.110.158
A    www              69.62.110.158
CNAME www             ayyildizajans.com
```

### Özellikler

- ✅ Nginx reverse proxy
- ✅ PostgreSQL veritabanı
- ✅ Let's Encrypt SSL
- ✅ Gunicorn WSGI server
- ✅ Systemd servisi
- ✅ Firewall yapılandırması
- ✅ Otomatik SSL yenileme
- ✅ Gzip sıkıştırma
- ✅ Güvenlik başlıkları
- ✅ Log rotasyonu
- ✅ Sistem optimizasyonu

### Sorun Giderme

```bash
# Servis durumu
systemctl status ayyildizhaber
systemctl status nginx

# Logları görüntüle
journalctl -u ayyildizhaber -f

# Yeniden başlat
systemctl restart ayyildizhaber
```

### Güvenlik

- UFW firewall (80, 443, 22 portları)
- Fail2ban brute force koruması
- SSL/TLS güvenlik başlıkları
- Güvenli PostgreSQL yapılandırması
