#!/bin/bash

# Ayyıldız Haber Ajansı - Hızlı VPS Kurulumu
# Ubuntu 24.04 için optimize edilmiş

echo "=== Ayyıldız Haber Ajansı VPS Kurulumu ==="

# Dosyaları kopyala
mkdir -p /tmp/ayyildizhaber
cp -r * /tmp/ayyildizhaber/

# Ana kurulum scriptini çalıştır
chmod +x /tmp/ayyildizhaber/vps-install.sh
cd /tmp/ayyildizhaber
./vps-install.sh

echo "Kurulum tamamlandı!"
echo "Site: https://www.ayyildizajans.com"
echo "IP: https://69.62.110.158"
